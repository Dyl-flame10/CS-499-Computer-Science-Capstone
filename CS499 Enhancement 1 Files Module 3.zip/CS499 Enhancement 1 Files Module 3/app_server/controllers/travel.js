const TripsEndpoint = 'http://localhost:3000/api/trips';
const options =  {
    method : 'GET',
    headers : {
        'Accept' : 'application/json' // Return JSON data from request
    }
}
/*
* static file pulling method before Mod 5 API setup
*
* var fs = require('fs'); 
* var trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));
*
*
* GET travel view 
*
* const travel = (req, res) => {
* res.render('travel', { title: 'Travlr Getaways', trips});
* };
*/


/* GET travel view */
const travel = async function (req, res, next) {
  await fetch(TripsEndpoint, options)
    .then((res) => res.json())
    .then((json) => {
      let message = null;

      if (!(json instanceof Array)) { // API JSON error handling
        message = 'API lookup error';
        json = [];
      } else {
        if (!json.length) {
          message = 'No trips exist in our database!';
        }
      }

      res.render('travel', {
        title: 'Travlr Getaways',
        trips: json,
        message
      });
    })
    .catch((err) => res.status(500).send(err.message));
};

module.exports = {
  travel
};